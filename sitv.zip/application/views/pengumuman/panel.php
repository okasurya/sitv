<?php
    $this->load->view('template/header');
?>
    <link rel="stylesheet" href="<?=base_url()?>public/flexigrid/flexigrid.css">
    <script type="text/javascript" src="<?php echo base_url(); ?>public/flexigrid/flexigrid.js"></script> 
    <h1>Admin Panel</h1>
    <div id="flex"></div>
    <script type="text/javascript">
        
    <?php echo $js_grid; ?>
    function test(com,grid)
    {
            if (com=='Add')
            {
                location.href="<?=site_url('pengumuman/pengumuman/tambah_pengumuman')?>"; 
            }

            if (com=='Select All')
            {
                    $('.bDiv tbody tr',grid).addClass('trSelected');
            }

            if (com=='DeSelect All')
            {
                    $('.bDiv tbody tr',grid).removeClass('trSelected');
            }

            if (com=='Delete')
                    {
                       if($('.trSelected',grid).length>0){
                               if(confirm('Anda yakin ingin menghapus ' + $('.trSelected',grid).length + ' data cabang?')){
                                            var items = $('.trSelected',grid);
                                            var itemlist ='';
                                            for(i=0;i<items.length;i++){
                                                    itemlist+= items[i].id.substr(3)+",";
                                            }
                                            $.ajax({
                                               type: "POST",
                                               url: "<?php echo site_url("pengumuman/pengumuman/delete");?>",
                                               data: "items="+itemlist,
                                               success: function(data){
                                                    $('#flex').flexReload();
                                                    alert(data);
                                               }
                                            });
                                    }
                            } else {
                                    return false;
                            } 
                    }     

    }
    </script>
    
<?php
    $this->load->view('template/footer');
?>
