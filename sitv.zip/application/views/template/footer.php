    </div>
</div>
<hr>
<footer>
                <p>&copy; Kelompok 3 - MPTI D - SISTEM INFORMASI ITS - 2013</p>
</footer>
</div> <!-- /container -->
        
        <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>-->
        <script>window.jQuery || document.write('<script src="<?=base_url()?>public/site/js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="<?=base_url()?>public/site/js/vendor/bootstrap.min.js"></script>
        <script src="<?=base_url()?>public/site/js/plugins.js"></script>
        <script src="<?=base_url()?>public/site/js/main.js"></script>

<!--        <script>
            var _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];
            (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
            g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
            s.parentNode.insertBefore(g,s)}(document,'script'));
        </script>-->
    </body>
</html>
