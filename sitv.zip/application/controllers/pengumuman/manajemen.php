<?php
    class Manajemen extends CI_Controller{
        function Manajemen(){
            parent::__construct();
            if(!$this->session->userdata('logged_in')) redirect('auth/login');
            $this->load->helper('flexigrid');
            $this->load->library('flexigrid');
            $this->load->model('pengumuman_model');        
        }
        
        function index(){
            $this->panel();
        }
        
        function panel(){
            	$colModel['id'] = array('ID',40,TRUE,'center',0);
		$colModel['edit'] = array('Edit',50, false, 'center', 0);
		$colModel['judul_pengumuman'] = array('Judul Pengumuman',150,TRUE,'center',1);
		$colModel['deskripsi_pengumuman'] = array('Deskripsi Pengumuman',150,TRUE,'center',0);
//		if($this->session->userdata('role') == 1){
//			$colModel['edit_indeks'] = array('Ubah Indeks',60,FALSE,'center',0);
//		}
		$colModel['mulai_tayang'] = array('Mulai Tayang',120,TRUE,'center',1);
		$colModel['selesai_tayang'] = array('Selesai Tayang',120,TRUE,'center',1);
		$colModel['jenis_pengumuman'] = array('Jenis Pengumuman',80, TRUE,'center',1);
		$colModel['file'] = array('File',80, TRUE, 'center',1);
		$colModel['pengisi_pengumuman'] = array('Pengisi Pengumuman',80, TRUE, 'center',1);
		$colModel['status'] = array('Status',80, TRUE, 'center',1);		
                $colModel['timestamp'] = array('Timestamp',80, TRUE, 'center',1);		
		
		/*
		 * Aditional Parameters
		 */
		$gridParams = array(
                    'width' => 860,
                    'height' => 400,
                    'rp' => 15,
                    'rpOptions' => '[10,15,20,25,40]',
                    'pagestat' => 'Displaying: {from} to {to} of {total} items.',
                    'blockOpacity' => 0.5,
//                    'title' => 'Daftar Pengumuman',
                    'usepager'=> true,
                    'useRp' => true,
                    'showTableToggleBtn' => true,
                    'nowrap' => false
		);
		
		/*
		 * 0 - display name
		 * 1 - bclass
		 * 2 - onpress
		 */
		
		$buttons[] = array('Add','add','test');
		

		
		//Build js
		//View helpers/flexigrid_helper.php for more information about the params on this function
		$grid_js = build_grid_js('flex',site_url("pengumuman/manajemen/grid_panel"),$colModel,'id pengumuman','asc',$gridParams,$buttons);
		
		/*$data['js_grid'] = $grid_js;
		$data['version'] = "0.36";
		$data['download_file'] = "Flexigrid_CI_v0.36.rar";
		echo '<textarea>'.$grid_js.'</textarea>';
		$this->load->view('cabang/cabang_view',$data);*/
		
		$data['js_grid'] = $grid_js;
                //rendering view
                $data['title'] = 'Daftar Pengumuman';
		//$data['test'] = $this->cabang_model->get_cabang()->result();
		$this->load->view('pengumuman/panel',$data);
		
        }
        
        function grid_panel(){
            $valid_fields = array('id','judul_pengumuman', 'deskripsi_pengumuman');
            $this->flexigrid->validate_post('id_pengumuman', 'asc', $valid_fields);
            $records = $this->pengumuman_model->select();
            $this->output->set_header($this->config->item('json_header'));

            foreach ($records['records']->result() as $row) {
                $link_edit = "<a href='".site_url('pengumuman/pengumuman/edit_pengumuman').'/'.$row->ID_PENGUMUMAN."'>";
                $image_edit = base_url('public/images/icons/edit.png');

                            //$ubah_indeks = '<img src="'. base_url() . 'images/main/edit.png" onclick="ubah_indeks('.$row->ID_CABANG.','.$row->INDEKS.')" style="cursor:pointer;">';

                            //if($this->session->userdata('role') == 1){

                                    $record_items[] = array(
                                            $row->ID_PENGUMUMAN,
                                            $row->ID_PENGUMUMAN,
                                            $link_edit.'<img src="'.$image_edit.'"></a>',
                                            $row->JUDUL_PENGUMUMAN,
                                            $row->DESKRIPSI_PENGUMUMAN,
                                            //$ubah_indeks,
                                            $row->TANGGAL_MULAI,
                                            $row->TANGGAL_SELESAI,
                                            $row->ID_JENIS_PENGUMUMAN,
                                            $row->LOKASI_FILE_PENGUMUMAN,
                                            $row->ID_PENGISI_PENGUMUMAN,
                                            $row->ID_STATUS_PENGUMUMAN,
                                            $row->TIMESTAMP_PENGUMUMAN

                                    );
                            //}
                            //else{

//                                    $record_items[] = array(
//                                            $row->ID_CABANG,
//                                            $row->ID_CABANG,
//                                            $link_edit.'<img src="'.$image_edit.'"></a>',
//                                            $row->NAMA_CABANG,
//                                            $row->INDEKS,
//                                            $row->ALAMAT_CABANG,
//                                            $row->KODE_POS,
//                                            $row->PO_BOX,
//                                            $row->TELP,
//                                            $row->FAX,
//                                            $row->WEBSITE,
//                                            $row->EMAIL
//
//                                    );
                            //}
            }

            if (isset($record_items))
                $this->output->set_output($this->flexigrid->json_build($records['record_count'], $record_items));
            else
                $this->output->set_output('{"page":"1","total":"0","rows":[]}');
        }
    }
?>